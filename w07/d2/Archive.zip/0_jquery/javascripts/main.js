var Paint = Paint || {};

$( document ).ready(function() {
  Paint.generateTiles(10, 64, 64);
});
