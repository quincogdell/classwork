$( document ).ready(function() {
  $('h1').on("click", function() {
    $("body").css("background-color", "pink"); // NOTE: These are inline styles
  });
});
