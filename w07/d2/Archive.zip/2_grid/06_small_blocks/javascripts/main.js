var Paint = Paint || {};

$( document ).ready(function() {
  Paint.generateTiles(80, 110, 12); // NEW: this was changed so that things are smaller
});
