$( document ).ready(function() {
  new Paint;
});
