var Paint = Paint || {};

$( document ).ready(function() {
  Paint.generateTiles(15, 23, 64);
});
